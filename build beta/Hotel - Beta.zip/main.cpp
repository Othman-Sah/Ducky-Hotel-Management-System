#include "Hotel.h"
#include <iostream>
#include <limits>
using namespace std;

void afficherMenu() {
    cout << "\n========== Systeme de Gestion d'Hotel ==========" << endl;
    cout << "1. Afficher toutes les chambres" << endl;
    cout << "2. Afficher les chambres disponibles" << endl;
    cout << "3. Reserver une chambre" << endl;
    cout << "4. Liberer une chambre" << endl;
    cout << "5. Rechercher une chambre" << endl;
    cout << "6. Quitter" << endl;
    cout << "================================================" << endl;
    cout << "Entrez votre choix: ";
}

int main() {
    Hotel hotel("Hotel EMSI");
    
    hotel.ajouterChambre(101, "Simple", 500.0);
    hotel.ajouterChambre(102, "Simple", 500.0);
    hotel.ajouterChambre(201, "Double", 800.0);
    hotel.ajouterChambre(202, "Double", 800.0);
    hotel.ajouterChambre(301, "Suite", 1500.0);
    hotel.ajouterChambre(302, "Suite", 1500.0);
    hotel.ajouterChambre(401, "Deluxe", 2000.0);
    
    int choix;
    int numeroChambre;
    string nomClient;
    
    while (true) {
        afficherMenu();
        cin >> choix;
        
        if (cin.fail()) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Entree invalide! Veuillez entrer un numero." << endl;
            continue;
        }
        
        switch (choix) {
            case 1:
                hotel.afficherToutesChambres();
                break;
                
            case 2:
                hotel.afficherChambresDisponibles();
                break;
                
            case 3:
                cout << "Entrez le numero de chambre a reserver: ";
                cin >> numeroChambre;
                cin.ignore();
                cout << "Entrez le nom du client: ";
                getline(cin, nomClient);
                hotel.reserverChambre(numeroChambre, nomClient);
                break;
                
            case 4:
                cout << "Entrez le numero de chambre a liberer: ";
                cin >> numeroChambre;
                hotel.libererChambre(numeroChambre);
                break;
                
            case 5:
                cout << "Entrez le numero de chambre a rechercher: ";
                cin >> numeroChambre;
                hotel.rechercherChambre(numeroChambre);
                break;
                
            case 6:
                cout << "Merci d'avoir utilise le Systeme de Gestion d'Hotel!" << endl;
                return 0;
                
            default:
                cout << "Choix invalide! Veuillez reessayer." << endl;
        }
    }
    
    return 0;
}
