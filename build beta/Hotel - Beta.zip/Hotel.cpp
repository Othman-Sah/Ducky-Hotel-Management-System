#include "Hotel.h"
#include <iostream>
using namespace std;

Hotel::Hotel(const string& nom) : nomHotel(nom) {
    cout << "Bienvenue a " << nomHotel << "!" << endl;
}

void Hotel::ajouterChambre(int numero, const string& type, double prix) {
    chambres.push_back(Room(numero, type, prix));
}

void Hotel::afficherToutesChambres() const {
    cout << "\n=== Toutes les chambres de " << nomHotel << " ===" << endl;
    for (const auto& chambre : chambres) {
        chambre.afficherInfo();
    }
    cout << endl;
}

void Hotel::afficherChambresDisponibles() const {
    cout << "\n=== Chambres Disponibles ===" << endl;
    bool trouve = false;
    for (const auto& chambre : chambres) {
        if (chambre.getDisponibilite()) {
            chambre.afficherInfo();
            trouve = true;
        }
    }
    if (!trouve) {
        cout << "Aucune chambre disponible!" << endl;
    }
    cout << endl;
}

void Hotel::reserverChambre(int numeroChambre, const string& nomClient) {
    for (auto& chambre : chambres) {
        if (chambre.getNumeroChambre() == numeroChambre) {
            chambre.reserverChambre(nomClient);
            return;
        }
    }
    cout << "Chambre " << numeroChambre << " introuvable!" << endl;
}

void Hotel::libererChambre(int numeroChambre) {
    for (auto& chambre : chambres) {
        if (chambre.getNumeroChambre() == numeroChambre) {
            chambre.libererChambre();
            return;
        }
    }
    cout << "Chambre " << numeroChambre << " introuvable!" << endl;
}

void Hotel::rechercherChambre(int numeroChambre) const {
    for (const auto& chambre : chambres) {
        if (chambre.getNumeroChambre() == numeroChambre) {
            cout << "\n=== Details de la Chambre ===" << endl;
            chambre.afficherInfo();
            cout << endl;
            return;
        }
    }
    cout << "Chambre " << numeroChambre << " introuvable!" << endl;
}
