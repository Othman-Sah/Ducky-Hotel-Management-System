#ifndef ROOM_H
#define ROOM_H

#include <string>
using namespace std;

class Room {
private:
    int numeroChambre;
    string typeChambre;
    double prixParNuit;
    bool estDisponible;
    string nomClient;

public:
    Room(int numero, string type, double prix);
    
    int getNumeroChambre() const { return numeroChambre; }
    string getTypeChambre() const { return typeChambre; }
    double getPrixParNuit() const { return prixParNuit; }
    bool getDisponibilite() const { return estDisponible; }
    string getNomClient() const { return nomClient; }
    
    void reserverChambre(const string& nom);
    void libererChambre();
    void afficherInfo() const;
};

#endif
