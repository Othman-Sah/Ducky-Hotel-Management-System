#ifndef HOTEL_H
#define HOTEL_H

#include "Room.h"
#include <vector>
using namespace std;

class Hotel {
private:
    string nomHotel;
    vector<Room> chambres;

public:
    Hotel(const string& nom);
    
    void ajouterChambre(int numero, const string& type, double prix);
    void afficherToutesChambres() const;
    void afficherChambresDisponibles() const;
    void reserverChambre(int numeroChambre, const string& nomClient);
    void libererChambre(int numeroChambre);
    void rechercherChambre(int numeroChambre) const;
};

#endif
