#include "Room.h"
#include <iostream>
using namespace std;

Room::Room(int numero, string type, double prix) 
    : numeroChambre(numero), typeChambre(type), prixParNuit(prix), estDisponible(true), nomClient("") {}

void Room::reserverChambre(const string& nom) {
    if (estDisponible) {
        nomClient = nom;
        estDisponible = false;
        cout << "Chambre " << numeroChambre << " reservee avec succes pour " << nom << endl;
    } else {
        cout << "Chambre " << numeroChambre << " est deja occupee!" << endl;
    }
}

void Room::libererChambre() {
    if (!estDisponible) {
        cout << "Client " << nomClient << " a libere la chambre " << numeroChambre << endl;
        nomClient = "";
        estDisponible = true;
    } else {
        cout << "Chambre " << numeroChambre << " est deja libre!" << endl;
    }
}

void Room::afficherInfo() const {
    cout << "Chambre " << numeroChambre << " | Type: " << typeChambre 
         << " | Prix: " << prixParNuit << " DH/nuit | Statut: " 
         << (estDisponible ? "Disponible" : "Occupee");
    if (!estDisponible) {
        cout << " | Client: " << nomClient;
    }
    cout << endl;
}
