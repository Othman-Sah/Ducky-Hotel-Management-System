#include "Hotel.h"
#include "HotelServices.h"
#include "Authentication.h"
#include "User.h"
#include "ConsoleUI.h"
#include "Bill.h"
#include <iostream>
#include <limits>
#include <vector>
#include <cstdlib>

void clearScreen() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

User* showLoginScreen(Authentication& auth) {
    std::string username, password;
    User* loggedInUser = nullptr;

    while (loggedInUser == nullptr) {
        clearScreen();
        ConsoleUI::drawHeader("SYSTEME AUTHENTIFICATION");
        std::cout << "Entrez votre nom d'utilisateur: ";
        std::cin >> username;
        std::cout << "Entrez votre mot de passe: ";
        std::cin >> password;

        // Role is now determined automatically by the backend
        loggedInUser = auth.login(username, password);

        if (loggedInUser == nullptr) {
            ConsoleUI::drawInfoBox({"Identifiants incorrects. Veuillez reessayer."});
            system("pause");
        }
    }
    return loggedInUser;
}

void showDashboard(Hotel& hotel) {
    std::vector<std::string> info;
    info.push_back("Chambres occupees: " + std::to_string(hotel.getOccupiedRoomsCount()));
    info.push_back("Chambres disponibles: " + std::to_string(hotel.getAvailableRoomsCount()));
    info.push_back("Revenu total estime: $" + std::to_string(hotel.getTotalRevenue()));
    ConsoleUI::drawInfoBox(info);
    system("pause");
}

std::vector<MenuItem> commanderDuMenu() {
    std::vector<MenuItem> commande;
    std::string nomArticle;
    while (true) {
        std::cout << "Entrez le nom de l'article a commander (ou 'fin' pour terminer): ";
        std::cin >> nomArticle;
        if (nomArticle == "fin") {
            break;
        }

        bool articleTrouve = false;
        for (const auto& categorie : Restaurant::menu) {
            for (const auto& article : categorie.second) {
                if (article.name == nomArticle) {
                    commande.push_back(article);
                    std::cout << nomArticle << " ajoute a la commande.\n";
                    articleTrouve = true;
                    break;
                }
            }
            if (articleTrouve) break;
        }
        
        if (!articleTrouve) {
            std::cout << "Article non trouve.\n";
        }
    }
    return commande;
}

void adminManageRooms(Hotel& hotel, Authentication& auth) {
    int choix;
    int numeroChambre;
    std::string nomClient;
    int nuits;
    std::string username, password;

    while (true) {
        clearScreen();
        ConsoleUI::drawHeader("ADMIN - Gestion des Chambres");
        ConsoleUI::drawMenu({"Afficher toutes les chambres", "Afficher disponibles", "Reserver (Force)", "Liberer (Check-out)", "Retour"});
        std::cin >> choix;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        switch (choix) {
            case 1: hotel.afficherToutesChambres(); system("pause"); break;
            case 2: hotel.afficherChambresDisponibles(); system("pause"); break;
            case 3: {
                clearScreen();
                ConsoleUI::drawHeader("NOUVELLE RESERVATION");
                hotel.afficherChambresDisponibles();
                
                std::cout << "Entrez le numero de chambre a reserver (0 pour annuler): ";
                std::cin >> numeroChambre;
                if (numeroChambre == 0) break;

                std::cout << "Entrez le nom du client: ";
                std::cin.ignore();
                getline(std::cin, nomClient);
                std::cout << "Nombre de nuits: ";
                std::cin >> nuits;
                
                // Create User Account
                std::cout << "\n--- Creation Compte Client ---\n";
                std::cout << "Nom d'utilisateur: "; std::cin >> username;
                std::cout << "Mot de passe: "; std::cin >> password;

                Room* room = hotel.findRoom(numeroChambre);
                if (room && room->getDisponibilite()) {
                    hotel.reserverChambre(numeroChambre, nomClient, nuits);
                    auth.addUser(username, password, Role::USER);
                    std::cout << "Reservation effectuee et compte cree!\n";
                } else {
                    std::cout << "Erreur: Chambre introuvable ou deja occupee.\n";
                }
                system("pause");
                break;
            }
            case 4:
                std::cout << "Entrez le numero de chambre: ";
                std::cin >> numeroChambre;
                hotel.libererChambre(numeroChambre);
                system("pause");
                break;
            case 5: return;
            default: ConsoleUI::drawInfoBox({"Choix invalide!"}); system("pause");
        }
    }
}

void adminManageRestaurant() {
    int choice;
    while(true) {
        clearScreen();
        ConsoleUI::drawHeader("ADMIN - Gestion Restaurant");
        ConsoleUI::drawMenu({"Voir Menu", "Ajouter Article", "Modifier Prix", "Retour"});
        std::cin >> choice;
        
        if (choice == 1) {
            Restaurant::displayMenu();
            system("pause");
        } else if (choice == 2) {
            std::string cat, name;
            double price;
            std::cout << "Categorie (Breakfast, Lunch, etc): "; std::cin >> cat;
            std::cout << "Nom: "; std::cin >> name;
            std::cout << "Prix: "; std::cin >> price;
            RestaurantManager::addItem(cat, name, price);
            std::cout << "Article ajoute!\n";
            system("pause");
        } else if (choice == 3) {
            std::string name;
            double price;
            std::cout << "Nom de l'article: "; std::cin >> name;
            std::cout << "Nouveau Prix: "; std::cin >> price;
            RestaurantManager::updatePrice(name, price);
            system("pause");
        } else if (choice == 4) return;
    }
}

void adminManageParking() {
    clearScreen();
    ConsoleUI::drawHeader("ADMIN - Gestion Parking");
    std::cout << "Total Places: " << ParkingManager::getTotalSpots() << "\n";
    std::cout << "Places Libres: " << ParkingManager::getAvailableSpots() << "\n";
    std::cout << "Places Occupees: " << (ParkingManager::getTotalSpots() - ParkingManager::getAvailableSpots()) << "\n";
    system("pause");
}

void adminDashboard(Hotel& hotel, User* user, Authentication& auth) {
    int choix;
    while (true) {
        clearScreen();
        ConsoleUI::drawHeader("TABLEAU DE BORD ADMIN");
        ConsoleUI::drawInfoBox({"Bienvenue Admin " + user->getUsername()});
        ConsoleUI::drawMenu({
            "Vue d'ensemble (Dashboard)", 
            "Gestion Chambres", 
            "Gestion Restaurant", 
            "Gestion Parking", 
            "Deconnexion"
        });

        std::cin >> choix;
        switch (choix) {
            case 1: showDashboard(hotel); break;
            case 2: adminManageRooms(hotel, auth); break;
            case 3: adminManageRestaurant(); break;
            case 4: adminManageParking(); break;
            case 5: return;
            default: break;
        }
    }
}

void userOrderRestaurant(Hotel& hotel) {
    Restaurant::displayMenu();
    std::vector<MenuItem> commande = commanderDuMenu();
    if (!commande.empty()) {
        std::cout << "Entrez votre numero de chambre pour la facturation: ";
        int roomNum;
        std::cin >> roomNum;
        Room* room = hotel.findRoom(roomNum);
        if (room && !room->getDisponibilite()) {
            RoomService* rs = new RoomService(roomNum, commande);
            hotel.addServiceToRoom(roomNum, rs);
            std::cout << "Commande envoyee en cuisine!\n";
        } else {
            std::cout << "Chambre invalide. Commande annulee.\n";
        }
    }
    system("pause");
}

void userBookParking(Hotel& hotel) {
    if (ParkingManager::getAvailableSpots() > 0) {
        std::cout << "Entrez votre numero de chambre: ";
        int roomNum;
        std::cin >> roomNum;
        std::cout << "Nombre de jours: ";
        int days;
        std::cin >> days;
        
        if (ParkingManager::occupySpot()) {
            Parking* p = new Parking(days);
            hotel.addServiceToRoom(roomNum, p);
            std::cout << "Place reservee! (Note: Simulation - place liberee manuellement ou a la fin)\n";
        }
    } else {
        std::cout << "Parking complet!\n";
    }
    system("pause");
}

void userBookSpa(Hotel& hotel) {
    std::cout << "Entrez votre numero de chambre: ";
    int roomNum;
    std::cin >> roomNum;
    Room* room = hotel.findRoom(roomNum);
    
    if (room && !room->getDisponibilite()) {
        std::string treatment;
        std::cout << "Entrez le soin desire (Massage, Facial, Sauna): ";
        std::cin.ignore();
        getline(std::cin, treatment);
        
        Spa* spa = new Spa(treatment);
        hotel.addServiceToRoom(roomNum, spa);
        std::cout << "Rendez-vous Spa reserve!\n";
    } else {
        std::cout << "Chambre invalide.\n";
    }
    system("pause");
}

void userBookGym(Hotel& hotel) {
    std::cout << "Entrez votre numero de chambre: ";
    int roomNum;
    std::cin >> roomNum;
    Room* room = hotel.findRoom(roomNum);
    
    if (room && !room->getDisponibilite()) {
        int hours;
        std::cout << "Nombre d'heures: ";
        std::cin >> hours;
        Gym* gym = new Gym(hours);
        hotel.addServiceToRoom(roomNum, gym);
        std::cout << "Acces Gym reserve!\n";
    } else {
        std::cout << "Chambre invalide.\n";
    }
    system("pause");
}

void userDashboard(Hotel& hotel, User* user) {
    int choix;
    while (true) {
        clearScreen();
        ConsoleUI::drawHeader("ESPACE CLIENT");
        ConsoleUI::drawInfoBox({"Bienvenue " + user->getUsername()});
        ConsoleUI::drawMenu({
            "Voir mes infos (Simule)", 
            "Restaurant (Menu & Commande)", 
            "Reserver Parking", 
            "Spa & Gym", 
            "Deconnexion"
        });

        std::cin >> choix;
        switch(choix) {
            case 1: 
                std::cout << "Fonctionnalite a venir: lier User a Room.\n"; 
                system("pause"); 
                break;
            case 2: userOrderRestaurant(hotel); break;
            case 3: userBookParking(hotel); break;
            case 4: 
                userBookSpa(hotel);
                userBookGym(hotel);
                break;
            case 5: return;
        }
    }
}

int main() {
    Authentication auth;
    Hotel hotel("Hotel Deluxe EMSI");
    Restaurant::initializeMenu();
    ParkingManager::initialize(50); // 50 Parking spots

    // Setup initial data
    hotel.ajouterChambre(101, "Simple", 500.0);
    hotel.ajouterChambre(102, "Simple", 500.0);
    hotel.ajouterChambre(201, "Double", 800.0);
    hotel.ajouterChambre(301, "Suite", 1500.0);
    hotel.loadReservations(); // Load saved reservations

    while (true) {
        User* loggedInUser = showLoginScreen(auth);
        
        if (loggedInUser->getRole() == Role::ADMIN) {
            adminDashboard(hotel, loggedInUser, auth);
        } else {
            userDashboard(hotel, loggedInUser);
        }
        
        // Reset for next user
        loggedInUser = nullptr;
    }

    return 0;
}

/* Old code removed for clarity and architecture fix */
/*
void gererServices(Hotel& hotel) {
    int choix;
    while (true) {
        clearScreen();
        afficherMenuServices();
        std::cin >> choix;
        if (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            ConsoleUI::drawInfoBox({"Entree invalide!"});
            system("pause");
            continue;
        }

        switch (choix) {
            case 1: Restaurant::displayMenu(); system("pause"); break;
            case 2: {
                Restaurant::displayMenu();
                std::vector<MenuItem> commande = commanderDuMenu();
                if (!commande.empty()) {
                    Restaurant* restaurant = new Restaurant(commande);
                    restaurant->bookService();
                    hotel.addService(restaurant);
                    ConsoleUI::drawInfoBox({"Note: This order is not tied to a room."});
                }
                system("pause");
                break;
            }
            case 3: {
                std::cout << "Entrez le numero de chambre pour le service: ";
                int numChambre;
                std::cin >> numChambre;
                if(hotel.findRoom(numChambre) == nullptr || hotel.findRoom(numChambre)->getDisponibilite()){
                    ConsoleUI::drawInfoBox({"Chambre non valide ou non occupee."});
                    break;
                }
                Restaurant::displayMenu();
                std::vector<MenuItem> commande = commanderDuMenu();
                if (!commande.empty()) {
                    RoomService* roomService = new RoomService(numChambre, commande);
                    roomService->bookService();
                    hotel.addServiceToRoom(numChambre, roomService);
                }
                system("pause");
                break;
            }
            case 4: {
                std::cout << "Entrez le numero de chambre pour le service: ";
                int numChambre;
                std::cin >> numChambre;
                 if(hotel.findRoom(numChambre) == nullptr || hotel.findRoom(numChambre)->getDisponibilite()){
                    ConsoleUI::drawInfoBox({"Chambre non valide ou non occupee."});
                    break;
                }
                std::cout << "Entrez le nombre de jours pour le parking: ";
                int jours;
                std::cin >> jours;
                Parking* parking = new Parking(jours);
                parking->bookService();
                hotel.addServiceToRoom(numChambre, parking);
                system("pause");
                break;
            }
            case 5: {
                 std::cout << "Entrez le numero de chambre pour le service: ";
                int numChambre;
                std::cin >> numChambre;
                 if(hotel.findRoom(numChambre) == nullptr || hotel.findRoom(numChambre)->getDisponibilite()){
                    ConsoleUI::drawInfoBox({"Chambre non valide ou non occupee."});
                    break;
                }
                std::cout << "Entrez le nom du soin spa desire: ";
                std::string soin;
                std::cin.ignore();
                getline(std::cin, soin);
                Spa* spa = new Spa(soin);
                spa->bookService();
                hotel.addServiceToRoom(numChambre, spa);
                system("pause");
                break;
            }
            case 6: {
                 std::cout << "Entrez le numero de chambre pour le service: ";
                int numChambre;
                std::cin >> numChambre;
                 if(hotel.findRoom(numChambre) == nullptr || hotel.findRoom(numChambre)->getDisponibilite()){
                    ConsoleUI::drawInfoBox({"Chambre non valide ou non occupee."});
                    break;
                }
                std::cout << "Entrez le nombre d'heures pour la salle de sport: ";
                int heures;
                std::cin >> heures;
                Gym* gym = new Gym(heures);
                gym->bookService();
                hotel.addServiceToRoom(numChambre, gym);
                system("pause");
                break;
            }
            case 7: return;
            default: ConsoleUI::drawInfoBox({"Choix invalide!"}); system("pause");
        }
    }
*/